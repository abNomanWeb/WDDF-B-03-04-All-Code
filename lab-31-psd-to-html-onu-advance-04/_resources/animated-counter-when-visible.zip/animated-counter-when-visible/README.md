# Animated Counter
Javascript / Jquery animated counter

Multiple instances <br>
Each counters group starts when it becommes visible<br>
Optional configurable speed for each counter<br>
Very easy to implement<br>
Jquery is required<br>
